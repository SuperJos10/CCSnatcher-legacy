import random
import time

def generate_number():
    # Generate 4 random 4-digit sections
    sections = [str(random.randint(0000, 9999)) for _ in range(4)]
    
    # Join the sections with spaces to form a 16-digit number
    number = ' '.join(sections)
    
    return number

def main():
    generated_numbers = []

    try:
        while True:
            # Wait for a random amount of time between 1.2 and 15.6 seconds
            wait_time = random.uniform(1.2, 15.6)
            time.sleep(wait_time)

            # Generate a 16-digit number
            number = generate_number()

            # Print the generated number
            print("SCRAPED BY BK_X:", number, "   !!THESE ARE DUMMY CARDS!!")

            # Add the generated number to the list
            generated_numbers.append(number)
            
    except KeyboardInterrupt:
        # Save all the generated numbers to a file when the program is terminated
        with open("generated_numbers.txt", "w") as f:
            for num in generated_numbers:
                f.write(num + "\n")
        print("Generated numbers have been saved to 'generated_numbers.txt'.")

if __name__ == "__main__":
    main()
